package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.models.Curso;

@Repository
public interface CursoRepository extends JpaRepository<Curso, Long> {

    void deleteByNombre(String nombre);

    void deleteByFechaInicio(String fechaInicio);

    Optional<Curso> findByNombre(String nombre);

    List<Curso> findByFechaInicio(String fechaInicio);
}

