package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.Curso;
import com.example.demo.repository.CursoRepository;

@Service
public class CursoService {

    @Autowired
    private CursoRepository cursoRepository;
    // Obtener todos los cursos
    
    public List<Curso> getAllCursos() {
        return cursoRepository.findAll();
    }

    public Curso saveCurso(Curso curso) {
        return cursoRepository.save(curso);
    }

    public Optional<Curso> getCursoById(Long id) {
        return cursoRepository.findById(id);
    }

    public void deleteCursoById(Long id) {
        cursoRepository.deleteById(id);
    }

    public void deleteCursoByNombre(String nombre) {
        cursoRepository.deleteByNombre(nombre);
    }

    public void deleteCursoByFechaInicio(String fechaInicio) {
        cursoRepository.deleteByFechaInicio(fechaInicio);
    }
}
